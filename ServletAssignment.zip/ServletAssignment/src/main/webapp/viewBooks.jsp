<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.*,com.library.model.Book" %>

<table border="1">

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Author</th>
    <th>Price</th>
    <th>Action</th>
</tr>

<%
List<Book> books = (List<Book>)request.getAttribute("books");

for(Book b : books)
{
%>

<tr>
    <td><%=b.getBid()%></td>
    <td><%=b.getBname()%></td>
    <td><%=b.getAuthor()%></td>
    <td><%=b.getPrice()%></td>

    <td>
        <a href="updateBook.jsp?bid=<%=b.getBid()%>&bname=<%=b.getBname()%>&author=<%=b.getAuthor()%>&price=<%=b.getPrice()%>">
            Edit
        </a>
    </td>
</tr>

<%
}
%>

</table>

<a href="addBook.jsp">Add Book</a><br><br>
<a href="dashboard.jsp">Dashboard</a><br><br>
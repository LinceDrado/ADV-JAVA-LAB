<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%
    if(session.getAttribute("user")==null)
    {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<h2>Library Dashboard</h2>

<a href="addBook.jsp">Add Book</a><br><br>

<a href="viewBooks">View Books</a><br><br>

<a href="logout">Logout</a>
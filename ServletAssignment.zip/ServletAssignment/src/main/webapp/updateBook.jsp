<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%
if(session.getAttribute("user")==null)
{
    response.sendRedirect("login.jsp");
    return;
}

String bid = request.getParameter("bid");
String bname = request.getParameter("bname");
String author = request.getParameter("author");
String price = request.getParameter("price");
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Update Book</title>
</head>
<body>

<h2>Update Book</h2>

<form action="updateBook" method="post">

    Book Id:
    <input type="number"
           name="bid"
           value="<%=bid%>"
           readonly>
    <br><br>

    Book Name:
    <input type="text"
           name="bname"
           value="<%=bname%>">
    <br><br>

    Author:
    <input type="text"
           name="author"
           value="<%=author%>">
    <br><br>

    Price:
    <input type="text"
           name="price"
           value="<%=price%>">
    <br><br>

    <input type="submit" value="Update Book">

</form>

<br>
<a href="viewBooks">Back</a>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%
    if(session.getAttribute("user")==null)
    {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<h2>Add Book</h2>

<form action="addBook" method="post">

    Book Id:
    <input type="number" name="bid"><br><br>

    Book Name:
    <input type="text" name="bname"><br><br>

    Author:
    <input type="text" name="author"><br><br>

    Price:
    <input type="text" name="price"><br><br>

    <input type="submit" value="Add">

</form>
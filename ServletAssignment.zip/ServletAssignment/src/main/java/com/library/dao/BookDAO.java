package com.library.dao;

import com.library.model.Book;
import com.library.util.DBUtil;

import java.sql.*;
import java.util.*;

public class BookDAO {

    public boolean addBook(Book book) {

        try(Connection con = DBUtil.getConnection()) {

            String sql =
                    "insert into book values(?,?,?,?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setInt(1, book.getBid());
            ps.setString(2, book.getBname());
            ps.setString(3, book.getAuthor());
            ps.setDouble(4, book.getPrice());

            return ps.executeUpdate() > 0;

        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public List<Book> getAllBooks() {

        List<Book> list = new ArrayList<>();

        try(Connection con = DBUtil.getConnection()) {

            String sql = "select * from book";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while(rs.next()) {

                Book b = new Book();

                b.setBid(rs.getInt("bid"));
                b.setBname(rs.getString("bname"));
                b.setAuthor(rs.getString("author"));
                b.setPrice(rs.getDouble("price"));

                list.add(b);
            }

        } catch(Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public boolean updateBook(Book book) {

        try(Connection con = DBUtil.getConnection()) {

            String sql =
                    "update book set bname=?,author=?,price=? where bid=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, book.getBname());
            ps.setString(2, book.getAuthor());
            ps.setDouble(3, book.getPrice());
            ps.setInt(4, book.getBid());

            return ps.executeUpdate() > 0;

        } catch(Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
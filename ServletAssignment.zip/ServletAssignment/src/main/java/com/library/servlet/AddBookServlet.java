package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.model.Book;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AddBookServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null) {

            response.sendRedirect("login.jsp");
            return;
        }

        Book book = new Book();

        book.setBid(
                Integer.parseInt(
                        request.getParameter("bid")));

        book.setBname(
                request.getParameter("bname"));

        book.setAuthor(
                request.getParameter("author"));

        book.setPrice(
                Double.parseDouble(
                        request.getParameter("price")));

        BookDAO dao = new BookDAO();

        dao.addBook(book);

        response.sendRedirect("viewBooks");
    }
}
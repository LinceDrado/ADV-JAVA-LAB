package com.library.servlet;

import com.library.util.DBUtil;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String username =
                request.getParameter("username");

        String password =
                request.getParameter("password");

        try(Connection con = DBUtil.getConnection()) {

            String sql =
                    "select * from login where username=? and password=?";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                HttpSession session =
                        request.getSession();

                session.setAttribute("user", username);

                response.sendRedirect("dashboard.jsp");

            } else {

                response.sendRedirect("login.jsp");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
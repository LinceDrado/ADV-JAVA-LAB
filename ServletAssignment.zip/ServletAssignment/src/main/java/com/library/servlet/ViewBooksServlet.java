package com.library.servlet;

import com.library.dao.BookDAO;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ViewBooksServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null) {

            response.sendRedirect("login.jsp");
            return;
        }

        BookDAO dao = new BookDAO();

        request.setAttribute(
                "books",
                dao.getAllBooks());

        RequestDispatcher rd =
                request.getRequestDispatcher(
                        "viewBooks.jsp");

        rd.forward(request, response);
    }
}
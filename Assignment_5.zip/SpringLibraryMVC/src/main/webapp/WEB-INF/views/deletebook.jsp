<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete Book</title>
</head>
<body>

	<h2>Delete Book</h2>

	<form action="deleteBookById" method="post">

		Book ID: <input type="text" name="bookId"> 
		
		<input type="submit" value="Delete">

	</form>

	<br>

	<a href="viewbooks">View Books</a>

</body>
</html>
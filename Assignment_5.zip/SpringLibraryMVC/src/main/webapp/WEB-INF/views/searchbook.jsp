<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Search Book</title>
</head>
<body>

	<h2>Search Books By Category</h2>

	<form action="searchByCategory" method="get">

		Category: <input type="text" name="category"> 
		<input type="submit" value="Search">

	</form>

	<br>

	<c:if test="${not empty books}">

		<table border="1" cellpadding="5">

			<tr>
				<th>Book ID</th>
				<th>Title</th>
				<th>Author</th>
				<th>Category</th>
				<th>Price</th>
			</tr>

			<c:forEach var="b" items="${books}">

				<tr>
					<td>${b.bookId}</td>
					<td>${b.title}</td>
					<td>${b.author}</td>
					<td>${b.category}</td>
					<td>${b.price}</td>
				</tr>

			</c:forEach>

		</table>

	</c:if>

	<br>
	<a href="addbook">Home</a>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<body>

	<h2>ADD Book</h2>

	<form action="save" method="post">

		Book ID : <input type="text" name="id" />
		 <br> <br> 
		Title : <input type="text" name="name" /> 
		<br> <br>
	    Author : <input type="text" name="author" /> 
		<br> <br> 
		Category : <input type="text" name="category" /> 
		<br> <br> 
		Price : <input type="text" name="price" /> 
		<br> <br>
		<input type="submit" value="Add Book" />

	</form>

	<br>

	<a href="viewbooks">View All Books</a>

</body>
</html>

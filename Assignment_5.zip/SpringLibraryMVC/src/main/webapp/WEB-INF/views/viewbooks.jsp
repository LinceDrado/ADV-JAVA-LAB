<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>View Books</title>
</head>
<body>

	<h2>All Books</h2>

	<table border="1" cellpadding="5">

		<tr>
			<th>Book ID</th>
			<th>Title</th>
			<th>Author</th>
			<th>Category</th>
			<th>Price</th>
		</tr>

		<c:forEach var="b" items="${books}">

			<tr>
				<td>${b.bookId}</td>
				<td>${b.title}</td>
				<td>${b.author}</td>
				<td>${b.category}</td>
				<td>${b.price}</td>
			</tr>

		</c:forEach>

	</table>

	<br>

	<a href="addbook">Add Book</a>
	<br><br>
	<a href="searchbook">Search Book</a>
	<br><br>
	<a href="deletebook">Delete Book</a>

</body>
</html>
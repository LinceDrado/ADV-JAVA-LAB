package com.cdac.model;

public class Book {
	private int BookId;
	private String title;
	private String author;
	private String category;
	private int price;

	public Book() {

	}

	public Book(int bookId, String title, String author, String category, int price) {
		BookId = bookId;
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
	}

	public int getBookId() {
		return BookId;
	}

	public void setBookId(int bookId) {
		BookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

}

package com.cdac.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.cdac.dao.BookDAO;
import com.cdac.model.Book;

@Controller
public class BookController {
	private BookDAO bookDAO;

	public void setBookDAO(BookDAO bookDAO) {

		this.bookDAO = bookDAO;
	}

	@GetMapping("/addbook")
	public String showAddBookPage() {
		return "addbook";
	}

	@PostMapping("/savebook")
	public String saveBook(@ModelAttribute Book book, Model model) {

		bookDAO.save(book);
		model.addAttribute("msg", "Book Added Successfully");
		return "success";
	}

	@GetMapping("/viewbooks")
	public String viewBooks(Model model) {
		List<Book> books = bookDAO.getAllBooks();
		model.addAttribute("books", books);

		return "viewbooks";
	}

	@GetMapping("/searchbook")
	public String showSearchPage() {
		return "searchbook";
	}

	@GetMapping("/searchByCategory")
	public String searchByCategory(@RequestParam String category, Model model) {

		List<Book> books = bookDAO.searchByCategory(category);

		model.addAttribute("books", books);

		return "searchbook";
	}

	@GetMapping("/deletebook")
	public String showDeletePage() {
		return "deletebook";
	}

	@PostMapping("/deleteBookById")
	public String deleteBook(@RequestParam int bookId, Model model) {

		bookDAO.deleteBook(bookId);

		model.addAttribute("msg", "Book Deleted Successfully");

		return "success";
	}

}

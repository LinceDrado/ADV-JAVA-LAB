package com.cdac.dao;

import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.cdac.model.Book;

public class BookDAO {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int save(Book book) {
		String sql = "insert into books values(?,?,?,?,?)";

		return jdbcTemplate.update(sql, book.getBookId(), book.getTitle(), book.getAuthor(), book.getCategory(),
				book.getPrice());
	}

	public List<Book> getAllBooks() {
		String sql = "select * from books";

		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Book.class));
	}

	public List<Book> searchByCategory(String category) {

		String sql = "select * from books where category=?";

		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Book.class), category);
	}

	public int deleteBook(int bookId) {

		String sql = "delete from books where bookId=?";

		return jdbcTemplate.update(sql, bookId);
	}

}

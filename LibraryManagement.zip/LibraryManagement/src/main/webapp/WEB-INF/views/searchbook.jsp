<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>


<html>
<body>

<h2>Search Book</h2>

<form action="searchBook" method="post">

    Category:

    <input type="text" name="category"/>

    <br><br>

    <input type="submit" value="Search"/>

</form>

</body>
</html>
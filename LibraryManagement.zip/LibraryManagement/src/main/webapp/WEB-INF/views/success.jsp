<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>


<html>
<body>

<h2>${msg}</h2>

<a href="add">Add Another Book</a>

<br><br>

<a href="view">View Books</a>

</body>
</html>
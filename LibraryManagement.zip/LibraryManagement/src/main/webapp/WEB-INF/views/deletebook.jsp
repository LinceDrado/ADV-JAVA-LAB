<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<body>

<h2>Delete Book</h2>

<form action="deleteBook" method="post">

    Book ID:

    <input type="text" name="bookId"/>

    <br><br>

    <input type="submit" value="Delete"/>

</form>

</body>
</html>
package com.cdac.FoodOrderSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodOrderSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

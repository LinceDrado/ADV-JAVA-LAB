package com.cdac.foodorderspringboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdac.foodorderspringboot.entity.FoodOrder;

public interface FoodRepository extends JpaRepository<FoodOrder, Integer>{

}

package com.cdac.foodorderspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cdac.foodorderspringboot.entity.FoodOrder;
import com.cdac.foodorderspringboot.service.FoodService;


@RestController
@RequestMapping("/orders")
public class FoodController {

    @Autowired
    private FoodService service;

    @PostMapping
    public FoodOrder placeOrder(@RequestBody FoodOrder order) {
        return service.placeOrder(order);
    }

    @GetMapping
    public List<FoodOrder> getAllOrders() {
        return service.getAllOrders();
    }

    @GetMapping("/{id}")
    public Object getOrderById(@PathVariable Integer id) {

        FoodOrder order = service.getOrderById(id);

        if (order != null) {
            return order;
        }

        return "Order Not Found";
    }

    @PutMapping("/{id}")
    public Object updateOrder(@PathVariable Integer id,
                              @RequestBody FoodOrder order) {

        FoodOrder updated = service.updateOrder(id, order);

        if (updated != null) {
            return updated;
        }

        return "Order Not Found";
    }

    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable Integer id) {

        if (service.deleteOrder(id)) {
            return "Order Deleted Successfully";
        }

        return "Order Not Found";
    }
}
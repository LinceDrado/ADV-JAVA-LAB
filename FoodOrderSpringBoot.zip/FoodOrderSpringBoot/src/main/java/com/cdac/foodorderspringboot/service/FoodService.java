package com.cdac.foodorderspringboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.foodorderspringboot.entity.FoodOrder;
import com.cdac.foodorderspringboot.repository.FoodRepository;


@Service
public class FoodService {

    @Autowired
    private FoodRepository repository;

    // Place New Order
    public FoodOrder placeOrder(FoodOrder order) {

        order.setTotalAmount(order.getQuantity() * order.getPricePerItem());

        return repository.save(order);
    }

    // View All Orders
    public List<FoodOrder> getAllOrders() {
        return repository.findAll();
    }

    // View Order By ID
    public FoodOrder getOrderById(Integer id) {
        Optional<FoodOrder> optional = repository.findById(id);
        return optional.orElse(null);
    }

    // Update Order
    public FoodOrder updateOrder(Integer id, FoodOrder updatedOrder) {

        Optional<FoodOrder> optional = repository.findById(id);

        if (optional.isPresent()) {

            FoodOrder order = optional.get();

            order.setQuantity(updatedOrder.getQuantity());
            order.setPricePerItem(updatedOrder.getPricePerItem());

            order.setTotalAmount(order.getQuantity() * order.getPricePerItem());

            return repository.save(order);
        }

        return null;
    }

    // Delete Order
    public boolean deleteOrder(Integer id) {

        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }

        return false;
    }
}
package com.cdac.foodorderspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodOrderSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodOrderSpringBootApplication.class, args);
	}

}
